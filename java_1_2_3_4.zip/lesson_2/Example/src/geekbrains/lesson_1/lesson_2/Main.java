package geekbrains.lesson_1.lesson_2;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	System.out.println("Введите число");
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        System.out.println("a="+a);
    }
}
