package geekbrains.lesson_3;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ваша задача - угадать число");
        int range = 13;
        int number = (int)(Math.random()*range);
        while (true) {
            System.out.println("Укадайте число от 0 до " +range);
            int input_number = scanner.nextInt(); //читаем число в консоли
            if (input_number == number) { //сравниваем с загаданным числом
                System.out.println("Вы угадали");
                break; //цикл прерывается, если число угадано
            } else if (input_number>number){
                System.out.println("Загаданное число меньше");
            } else {
                System.out.println("Загаданное число больше");
            }
        }
        scanner.close();
    }
}
