package geekbrains.lesson_7_1;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class GameWindow extends JFrame{

    private static GameWindow game_window;
    private static long last_frame_time; // переменная типа long позволяет хранить очень большие значения
    // подсчет времени, которое прошло между кадрами
    private static Image background;
    private static Image drop;
    private static Image game_over;
    private static float drop_left=200; //в этой переменной хранится координата X левого верхнего угла капли
    private static float drop_top=-100; //в этой переменной хранится координата Y левого верхнего угла капли
    private static float drop_v=400;//скорость капли



    public static void main(String[] args) throws IOException {

        background = ImageIO.read(GameWindow.class.getResourceAsStream("background.jpg"));
        drop = ImageIO.read(GameWindow.class.getResourceAsStream("drop.png"));
        game_over = ImageIO.read(GameWindow.class.getResourceAsStream("game_over.jpg"));

        game_window=new GameWindow();
        game_window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        game_window.setLocation(200,100);
        game_window.setSize(900,400);
        game_window.setResizable(false);
        last_frame_time=System.nanoTime(); //данная команда вовзращает текущее время в секундах
        GameField game_field = new GameField();
        game_window.add(game_field);
        game_window.setVisible(true);

    }

    private static void onRepaint (Graphics g){
        long current_time=System.nanoTime(); //переменная текущего времени
        float delta_time=(current_time - last_frame_time)*0.000000001f;
        //разница во времени:
        // (текущее время) - (время, которое было зафиксировано в предыдущем кадре)* (перевод полученного времени в обычные секунды из наносекунд)
        last_frame_time=current_time; //время предыдущего кадра равняется времени текущего кадра

        drop_top = drop_top + drop_v * delta_time;
        g.drawImage(background,0,0, null); // картинка рисуется в левом верхнем углу
        g.drawImage(drop,(int) drop_left,(int) drop_top, null); //int обрезает дробную часть
//        g.drawImage(game_over,280,120, null);

    }


    private static class GameField extends JPanel {
        @Override
        protected void paintComponent (Graphics g){
            super.paintComponent(g);
            onRepaint(g);
            repaint(); //позволяет вызывать paintComponent чаще
        }


    }
}
