package geekbrains.lesson_8;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

public class GameWindow extends JFrame{

    private static GameWindow game_window;
    private static long last_frame_time; // переменная типа long позволяет хранить очень большие значения
    // подсчет времени, которое прошло между кадрами
    private static Image background;
    private static Image drop;
    private static Image game_over;
    private static float drop_left=200; //в этой переменной хранится координата X левого верхнего угла капли
    private static float drop_top=-100; //в этой переменной хранится координата Y левого верхнего угла капли
    private static float drop_v=100;//скорость капли
    private static int score; //переменная для посчета очков. Изначально равна нулю



    public static void main(String[] args) throws IOException {

        background = ImageIO.read(GameWindow.class.getResourceAsStream("background.jpg"));
        drop = ImageIO.read(GameWindow.class.getResourceAsStream("drop.png"));
        game_over = ImageIO.read(GameWindow.class.getResourceAsStream("game_over.png"));

        game_window=new GameWindow();
        game_window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        game_window.setLocation(200,100);
        game_window.setSize(900,400);
        game_window.setResizable(false);
        last_frame_time=System.nanoTime(); //данная команда вовзращает текущее время в секундах
        GameField game_field = new GameField();
        game_field.addMouseListener(new MouseAdapter() { //перехват действий мыши
            @Override
            public void mousePressed(MouseEvent e) { //метод вызывается при применении мыши. MouseEvent передает координаты клика
                int x = e.getX(); // координата клика X
                int y = e.getY(); // координата клика Y
                float drop_right =  drop_left + drop.getWidth(null); // вычисляем координаты правой границы
                float drop_bottom = drop_top + drop.getHeight(null); // вычисляем координаты нижней границы
                boolean is_drop = x >= drop_left && x <= drop_right && y >= drop_top && y <= drop_bottom; //условие, которое отвечает на вопрос "попадает ли клик в каплю"
                if (is_drop) { //если клик мыши попал в каплю
                    drop_top = -100;
                    drop_left = (int) Math.random()*(game_field.getWidth()-drop.getWidth(null));
                    //число генерируется от 0 до ширины окна (game_field.getWidth) минус ширина капли (drop.getWidth)
                    drop_v = drop_v +10;
                    score ++; //с каждым попаданием по капле прибавляется одно очко
                    game_window.setTitle("Score: "+score); //отображение счетчика очков в окне игры
                }
                super.mousePressed(e);
            }
        });
        game_window.add(game_field);
        game_window.setVisible(true);

    }

    private static void onRepaint (Graphics g){
        long current_time=System.nanoTime(); //переменная текущего времени
        float delta_time=(current_time - last_frame_time)*0.000000001f;
        //разница во времени:
        // (текущее время) - (время, которое было зафиксировано в предыдущем кадре)* (перевод полученного времени в обычные секунды из наносекунд)
        last_frame_time=current_time; //время предыдущего кадра равняется времени текущего кадра

        drop_top = drop_top + drop_v * delta_time;
//        drop_left = drop_left + drop_v * delta_time; //капля по диагонали летит
        g.drawImage(background,0,0, null); // картинка рисуется в левом верхнем углу
        g.drawImage(drop,(int) drop_left,(int) drop_top, null); //int обрезает дробную часть
        if (drop_top > game_window.getHeight()) g.drawImage(game_over,135,120, null);
        //если капля вылетает за пределы окна, то отображается game_over

    }


    private static class GameField extends JPanel {
        @Override
        protected void paintComponent (Graphics g){
            super.paintComponent(g);
            onRepaint(g);
            repaint(); //позволяет вызывать paintComponent чаще
        }


    }
}

